package com.companyname;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;


public class TestDateApi {

	public static void main(String[] args) {
		
		System.out.println("-------Local Date------");
		LocalDate localDate=LocalDate.now();
		System.out.println("Local Date: "+localDate);
		
		int dateOfMonth=localDate.getDayOfMonth();
		System.out.println("Date of month: "+dateOfMonth);
		
		DayOfWeek dateOfWeek=localDate.getDayOfWeek();
		System.out.println("Date of Week: "+dateOfWeek);
		
		int dayOfYear=localDate.getDayOfYear();
		System.out.println("Date of Year: "+dayOfYear);
		
		LocalDate yesterday=localDate.minusDays(1);
		System.out.println("Yesterday Date: "+yesterday);
		
		LocalDate tomorrow=localDate.plusDays(1);
		System.out.println("Tomorrow Date: "+tomorrow);
		
		System.out.println("-------Local Date Time------");
		LocalDateTime localDateTime=LocalDateTime.now();
		System.out.println("Local Date Time: "+localDateTime);
		
		System.out.println("-------Date Time Formatter------");
		DateTimeFormatter dateTimeFormatter=DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss");
		String dateTimeFormatter1=localDateTime.format(dateTimeFormatter);
		System.out.println("Date Time Formatter: "+dateTimeFormatter1);
	}

}
