package com.companyname;

@FunctionalInterface
interface Employee{
	void employeeInfo(int employeeId,String employeeName);
	
	//Java8 feature
	default void info1(){
		System.out.println("default method");
	}
}

public class TestFunctionalInterface {

	public static void main(String[] args) {
		
		System.out.println("-----Java7-------");
		Employee employee=new Employee(){
			
			public void employeeInfo(int employeeId,String employeeName){
				System.out.println(employeeId+"\t"+employeeName);
			}
		};
		
		employee.employeeInfo(1, "James");
		employee.info1();
		
		System.out.println("-----Java8 feature Lambda Expression-------");
		Employee employee1=(employeeId,employeeName)->{
			System.out.println(employeeId+"\t"+employeeName);
		};
		
		employee1.employeeInfo(1, "James");
	}

}
