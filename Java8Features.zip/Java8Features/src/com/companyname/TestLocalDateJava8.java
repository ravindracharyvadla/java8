package com.companyname;

import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.Month;
import java.time.Period;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;

public class TestLocalDateJava8 {

	public static void main(String[] args) {

		LocalDate localDate=LocalDate.now();
		System.out.println("Local Date: "+localDate);
		
		int dateOfMonth=localDate.getDayOfMonth();
		System.out.println("Date of month: "+dateOfMonth);
		
		int year=localDate.getYear();
		System.out.println("Year: "+year);
		
		Month month=localDate.getMonth();
		System.out.println("Month: "+month);
		
		LocalDate yesterDay=localDate.minusDays(1);
		System.out.println("Yester Day Date: "+yesterDay);
		
		LocalDate tomorrow=localDate.plusDays(1);
		System.out.println("Tomorrow's Date: "+tomorrow);
		
		LocalDateTime localDateTime=LocalDateTime.now();
		System.out.println("Date: "+localDateTime);
		
		DateTimeFormatter dateTimeFormatter=DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss");
		String dateFormatter=localDateTime.format(dateTimeFormatter);
		System.out.println("Date Formatter: "+dateFormatter);
		
		ZonedDateTime zonedDateTime=ZonedDateTime.now();
		System.out.println("Zoned Date Time: "+zonedDateTime);
		System.out.println("Zone: "+zonedDateTime.getZone());
		
		
		Period period=Period.between(yesterDay, tomorrow);
		System.out.println("Period between: "+period);
		
		Duration duration=Duration.ofDays(1);
		System.out.println("Long Daya: "+duration);

	}

}
